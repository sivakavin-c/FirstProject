import java.util.Arrays;
public class FourthSmallestElement {
      public static int fourthElement(int arr[],int k) {
    	Arrays.sort(arr);
		return arr[k-1];
    	  
      }
	public static void main(String[] args) {
		int arr[]= {38,43,12,46,24,76,33,53};
		int k=4;
		System.out.println("Fourth Smallest Element: "+fourthElement(arr,k));

	}

}
