public class NewElementCLL {             
    public static void main(String[] args) {  
        NewElementCLL Obj = new NewElementCLL();  
        Obj.addFirst(1);  
        Obj.print();  
        Obj.addFirst(2);  
        Obj.print();  
        Obj.addFirst(3);  
        Obj.print();  
        Obj.addFirst(4);  
        Obj.print();  
        } 
    public class Node{  
        int element;  
        Node next; 
        
        public Node(int element) {  
            this.element = element;  
        }  
    } 

    public Node head = null;  
    public Node tail = null;
    
    public void print() {  
        Node current = head;    
        if(head == null) {  
            System.out.println("Empty List");  
        }  
        else {  
            System.out.println("After adding node at the beginning");  
            do{     
                //Prints each node by incrementing pointer.  
                System.out.print(" "+ current.element);  
                current = current.next;  
            }while(current != head);  
                        System.out.println();  
                    }  
                }
                
    public void addFirst(int data){  
        Node newNode = new Node(data);  
        if(head == null) {  
            head = newNode;  
            tail = newNode;  
            newNode.next = head;  
        }  
        else {  
            Node temp = head;  
            newNode.next = temp;  
            head = newNode;  
            tail.next = head;  
        }  
    }    
}    
