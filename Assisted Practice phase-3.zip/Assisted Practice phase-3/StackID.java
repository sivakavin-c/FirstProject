import java.util.Stack;  
public class StackID {

	public static void main(String[] args) {
		 
		Stack<Integer> stk= new Stack<Integer>();  
		  
		stk.push(78);  
		stk.push(113);  
		stk.push(90);  
		stk.push(120);  
		
		System.out.println("Elements in Stack: " + stk);  
		
		stk.pop();
		
		System.out.println("Elements in Stack: " + stk);
		}  
		

	}


