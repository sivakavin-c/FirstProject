import java.util.*;
public class SumRange {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			int L=sc.nextInt();
			int R=sc.nextInt();
			int i,sum=0;
			for(i=L;i<=R;i++) {
				sum+=i;
			}
			System.out.println("Sum between L and R: "+sum);
		}
		}
        

}
