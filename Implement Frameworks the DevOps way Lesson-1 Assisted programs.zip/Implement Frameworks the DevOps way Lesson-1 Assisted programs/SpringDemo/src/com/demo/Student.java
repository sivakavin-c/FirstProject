package com.demo;

public class Student {
	private String name;
	private int id;

	public Student() {
		System.out.println("I am default contructor");
	}
	public Student(int id) {
		this.id=id;
	}
	public Student(String name) {
		this.name=name;
	}
	public Student(int id,String name) {
		this.id=id;
		this.name=name;
	}
	public void getUserName() {
		System.out.println(id+" "+name);
	}
}
