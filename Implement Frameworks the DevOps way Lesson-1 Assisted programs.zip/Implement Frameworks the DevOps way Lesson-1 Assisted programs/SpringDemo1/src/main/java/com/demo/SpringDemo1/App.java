package com.demo.SpringDemo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.Custom.CustomEvent;
import com.demo.Custom.CustomEventPublisher;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
        Employee emp=(Employee)context.getBean("obj");
        emp.hello();
        
        System.out.println("Employee Id: "+emp.getId());
        System.out.println("Employee Name: "+emp.getName());
        
        Salary s=emp.getSal();
        
        System.out.println("Salary for fresher: "+s.getFresher());
        System.out.println("Salary for TL: "+s.getTL());
        System.out.println("Salary for Manager: "+s.getManager());
        
        
        ConfigurableApplicationContext context1=new ClassPathXmlApplicationContext("context.xml");
        context1.start();
        context1.stop();
        
        CustomEventPublisher customEvent=(CustomEventPublisher)context1.getBean("c2");
        customEvent.publish();
    }
}
