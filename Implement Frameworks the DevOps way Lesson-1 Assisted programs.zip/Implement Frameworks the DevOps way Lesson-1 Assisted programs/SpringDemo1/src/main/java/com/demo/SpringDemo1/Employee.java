package com.demo.SpringDemo1;

public class Employee {
	public void hello() {
		System.out.println("Hello world");
	}
	
	private int id;
	private String name;
	private Salary sal;
	public Salary getSal() {
		return sal;
	}
	public void setSal(Salary sal) {
		this.sal = sal;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
