package com.demo.SpringDemo1;

public class Salary {
	private float fresher;
	private float TL;
	private float Manager;
	public float getFresher() {
		return fresher;
	}
	public void setFresher(float fresher) {
		this.fresher = fresher;
	}
	public float getTL() {
		return TL;
	}
	public void setTL(float tL) {
		TL = tL;
	}
	public float getManager() {
		return Manager;
	}
	public void setManager(float manager) {
		Manager = manager;
	}
	
}
