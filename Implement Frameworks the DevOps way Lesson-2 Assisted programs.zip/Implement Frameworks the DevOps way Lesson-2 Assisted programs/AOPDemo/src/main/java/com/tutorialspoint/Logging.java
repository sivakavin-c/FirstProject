package com.tutorialspoint;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class Logging {
	@Pointcut("execution(* com.tutorialspoint.Student.getName(..))")
   private void selectgetName() {}
   @Before("selectgetName()")
   public void beforeAdvice(){
      System.out.println("Going to setup student profile.");
   }  
   @Pointcut("execution(* com.tutorialspoint.Student.getAge(..))")
   private void selectgetAge() {}
   @After("selectgetAge()")
   public void beforeAdvice1(){
      System.out.println("Going to setup student profile.");
   }  
}
