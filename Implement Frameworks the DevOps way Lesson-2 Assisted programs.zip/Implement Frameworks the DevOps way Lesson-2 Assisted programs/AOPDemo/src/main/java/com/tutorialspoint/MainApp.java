package com.tutorialspoint;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp 
{
    @SuppressWarnings("resource")
	public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("beans.xml");
        Student emp1=(Student) context.getBean("student");
        emp1.getName();
        emp1.getAge();
        
    }
}
