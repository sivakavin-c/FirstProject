package com.example;

public class ProductNotFoundException extends Exception{
	
	public ProductNotFoundException(String msg) {
		super(msg);
	}

	@Override
	public String toString() {
		return "ProductNotFoundException []";
	}
	
	
}
