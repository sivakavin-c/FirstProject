package com.simplilearn.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpsInSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpsInSpringBootApplication.class, args);
	}

}
