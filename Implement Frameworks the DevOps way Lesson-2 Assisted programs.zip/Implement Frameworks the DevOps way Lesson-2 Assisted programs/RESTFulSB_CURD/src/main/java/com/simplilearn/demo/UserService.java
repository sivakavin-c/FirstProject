package com.simplilearn.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UserService {
	@Autowired
	private Repo repo;
	
	public User addUser(User u){
		return repo.save(u);
	}
	
	public List<User> getUser() {
		return repo.findAll();
	}
	
	public User getUserById(int id) {
		if(repo.findById(id).isPresent()) 
			return repo.findById(id).get();
		else 
			return null;
		
	}
	
	public void save(User user) {
        repo.save(user);
    }
     
    public User get(int id) {
        return repo.findById(id).get();
    }
    
    public void delete(Integer id) {
        repo.deleteById(id);
    }
}
