package com.simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	private Calculator calc;
	@BeforeEach
	public void initialize() {
		calc=new Calculator();
		System.out.println("Object Initialized");
	}
	
	@Test
	public void testAdd() {
		assertEquals(7, calc.add(4, 3));
	}
	
	@Test
	public void testSub() {
		assertEquals(1, calc.sub(4, 3));
	}
	
	@Test
	public void testMul() {
		assertEquals(12, calc.mul(4, 3));
	}
	
	@Test
	public void testDiv() {
		assertEquals(2, calc.div(4, 2));
	}
	@AfterEach
	public void destroy() {
		calc=null;
		System.out.println("Object destroyed");
	}

}
