package com.simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

class ConditionalTest {

	@Test
	@EnabledOnOs({OS.WINDOWS})
	public void runOs() {
		System.out.println("Run on WINDOW OS");
	}
	
	@EnabledOnOs({OS.MAC})
	public void runMac() {
		System.out.println("Run on MAC OS");
	}
	
	@EnabledOnOs({OS.LINUX})
	public void runLinux() {
		System.out.println("Run on LINUX OS");
	}
}
