package com.simplilearn.demo;

import org.junit.jupiter.api.*;

public class JunitDemo {
	@BeforeAll
	public static void BeforeAll() {
		System.out.println("Before all");
	}
	@BeforeEach
	public void BeforeEach() {
		System.out.println("Before each");
	}
	@Test
	public void test() {
		System.out.println("Main test-1");
	}
	@Test
	public void test2() {
		System.out.println("Main test-2");
	}
	@AfterEach
	public void AfterEach() {
		System.out.println("After each");
	}
	@AfterAll
	public static void AfterAll() {
		System.out.println("After all");
	}
}
