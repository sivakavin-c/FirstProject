package com.simplilearn.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class NestedDemo {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("Before All");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("After all");
	}

	@BeforeEach
	void setUp() throws Exception {
		System.out.println("-----------------Setup OUTER------------------");
	}

	@AfterEach
	void tearDown() throws Exception {
		System.out.println("-----------------TearDown OUTER------------------");
	}

	@Test
	void test() {
		System.out.println("Test from OUTER");
	}
	@Nested
	class Inner{
		@BeforeEach
		void setUp() throws Exception {
			System.out.println("Setup INNER");
		}

		@AfterEach
		void tearDown() throws Exception {
			System.out.println("TearDown INNER");
		}

		@Test
		void test() {
			System.out.println("Test from INNER");
		}
	}
	@Nested
	class InsideInner{
		@BeforeEach
		void setUp() throws Exception {
			System.out.println("Setup INSIDEINNER");
		}

		@AfterEach
		void tearDown() throws Exception {
			System.out.println("TearDown INSIDEINNER");
		}

		@Test
		void test() {
			System.out.println("Test from INSIDEINNER");
		}
	}

}
