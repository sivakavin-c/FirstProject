package com.simplilearn.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;


@Service
public class UserService {
	@Autowired
	private Repo repo;
	
	public User addUser(User u){
		return repo.save(u);
	}
	
	public List<User> getUser() {
		return repo.findAll();
	}
	
	public User getUserById(int id) {
		if(repo.findById(id).isPresent()) 
			return repo.findById(id).get();
		else 
			return null;
		
	}
	
	public User updateUser(User user,int id) {
		User old=repo.findById(id).get();
		
		old.setName(user.getName());
		old.setCountry(user.getCountry());
		
		return repo.save(old);
	}
    
    public void delete(Integer id) {
        repo.deleteById(id);
    }

	
}
