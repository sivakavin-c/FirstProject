package com.simplilearn.demo;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestFulSbCurdApplicationTests {

	@Autowired
	private UserService service;
	
//	@Test
//	public void addTest() {
//		Assertions.assertNotNull(service.addUser(new User("jairam","Ukarine")));
//	}
//	
//	@Test
//	public void getUserTest() {
//		Assertions.assertEquals(1, service.getUser().size());
//	}
//	@Test
//    public void getByIDTest() {
//             Assertions.assertEquals("jairam",service.getUserById(1).getName());
//	}
	@Test
    public void UpdateByIDTest() {
             Assertions.assertNotNull(service.updateUser(new User("SIVA","INDIA"), 1));
}
}